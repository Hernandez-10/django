Descargas en el venv
Cuando creen el venv deben descargar estas dependencias
Django==4.2.7
django-filter==23.5
djangorestframework==3.14.0
Markdown==3.5.2
pillow==10.2.0
